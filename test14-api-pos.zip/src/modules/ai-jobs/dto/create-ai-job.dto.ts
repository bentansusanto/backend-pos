export class CreateAiJobDto {}
