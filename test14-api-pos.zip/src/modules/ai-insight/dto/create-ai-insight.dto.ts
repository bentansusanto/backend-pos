export class CreateAiInsightDto {}
