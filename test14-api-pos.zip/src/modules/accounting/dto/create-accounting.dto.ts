export class CreateAccountingDto {}
