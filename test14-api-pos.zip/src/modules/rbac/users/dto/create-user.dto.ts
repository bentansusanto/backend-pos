import { PartialType } from '@nestjs/mapped-types';
import { ApiProperty } from '@nestjs/swagger';
import {
  IsNotEmpty,
  IsOptional,
  IsString,
  Matches,
  MaxLength,
  MinLength,
} from 'class-validator';
import { Match } from 'src/common/decorator/match.decorator';
import { User } from '../entities/user.entity';

export class CreateUserDto {
  @ApiProperty({ example: 'John Doe', description: 'The name of the user' })
  @IsNotEmpty({ message: 'name is not empty' })
  @IsString({ message: 'name must be a string' })
  name: string;

  @ApiProperty({
    example: 'john@example.com',
    description: 'The email of the user',
  })
  @IsNotEmpty({ message: 'email is not empty' })
  @IsString({ message: 'email must be a string' })
  email: string;

  @ApiProperty({
    example: 'john_owner',
    description: 'The username of the user',
    required: false,
  })
  @IsOptional()
  @IsString({ message: 'username must be a string' })
  username?: string;

  @ApiProperty({
    example: 'Password123!',
    description: 'The password of the user',
  })
  @IsNotEmpty({ message: 'Password is required' })
  @MinLength(8, { message: 'Password must be at least 8 characters long' })
  @Matches(/(?=.*[a-z])/, {
    message: 'Password must contain at least one lowercase letter',
  })
  @Matches(/(?=.*[A-Z])/, {
    message: 'Password must contain at least one uppercase letter',
  })
  @Matches(/(?=.*\d)/, {
    message: 'Password must contain at least one number',
  })
  @Matches(/(?=.*[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?])/, {
    message: 'Password must contain at least one special character',
  })
  password: string;
}

export class CreateUserByOwnerDto {
  @ApiProperty({ example: 'John Doe', description: 'The name of the user' })
  @IsNotEmpty({ message: 'name is not empty' })
  @IsString({ message: 'name must be a string' })
  name: string;

  @ApiProperty({
    example: 'john@example.com',
    description: 'The email of the user',
  })
  @IsNotEmpty({ message: 'email is not empty' })
  @IsString({ message: 'email must be a string' })
  email: string;

  @ApiProperty({
    example: 'john_doe',
    description: 'The username of the user',
    required: false,
  })
  @IsOptional()
  @IsString({ message: 'username must be a string' })
  username?: string;

  @ApiProperty({
    example: '123456',
    description: 'The pin of the user',
    required: false,
  })
  @IsOptional()
  @IsString({ message: 'pin must be a string' })
  pin?: string;

  @ApiProperty({
    example: 'Password123!',
    description: 'The password of the user',
    required: false,
  })
  @IsOptional()
  @MinLength(8, { message: 'Password must be at least 8 characters long' })
  @Matches(/(?=.*[a-z])/, {
    message: 'Password must contain at least one lowercase letter',
  })
  @Matches(/(?=.*[A-Z])/, {
    message: 'Password must contain at least one uppercase letter',
  })
  @Matches(/(?=.*\d)/, {
    message: 'Password must contain at least one number',
  })
  @Matches(/(?=.*[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?])/, {
    message: 'Password must contain at least one special character',
  })
  password?: string;

  @IsNotEmpty({ message: 'role is not empty' })
  @IsString({ message: 'role must be a string' })
  role_id: string;

  @ApiProperty({
    example: 'branch-id-123',
    description: 'The branch id for the user',
    required: false,
  })
  @IsOptional()
  @IsString({ message: 'branch must be a string' })
  branch_id?: string;
}

export class LoginUserDto {
  @ApiProperty({
    example: 'john@example.com',
    description: 'The email of the user',
    required: false,
  })
  @IsOptional()
  @IsString({ message: 'email must be a string' })
  email?: string;

  @ApiProperty({
    example: 'john_doe',
    description: 'The username of the user',
    required: false,
  })
  @IsOptional()
  @IsString({ message: 'username must be a string' })
  username?: string;

  @ApiProperty({
    example: '123456',
    description: 'The pin of the user',
    required: false,
  })
  @IsOptional()
  @IsString({ message: 'pin must be a string' })
  pin?: string;

  @ApiProperty({
    example: 'Password123!',
    description: 'The password of the user',
    required: false,
  })
  @IsOptional()
  @MinLength(8, { message: 'Password must be at least 8 characters long' })
  @MaxLength(20, { message: 'Password must be at most 20 characters long' })
  @Matches(/(?=.*[a-z])/, {
    message: 'Password must contain at least one lowercase letter',
  })
  @Matches(/(?=.*[A-Z])/, {
    message: 'Password must contain at least one uppercase letter',
  })
  @Matches(/(?=.*\d)/, {
    message: 'Password must contain at least one number',
  })
  @Matches(/(?=.*[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?])/, {
    message: 'Password must contain at least one special character',
  })
  password?: string;
}

export class EmailRequest {
  @ApiProperty({
    example: 'john@example.com',
    description: 'The email of the user',
  })
  @IsNotEmpty({ message: 'email is not empty' })
  @IsString({ message: 'email must be a string' })
  email: string;
}

export class ResetPasswordDto {
  @ApiProperty({
    example: 'Password123!',
    description: 'The new password',
  })
  @IsNotEmpty({ message: 'Password is required' })
  @MinLength(8, { message: 'Password must be at least 8 characters long' })
  @MaxLength(20, { message: 'Password must be at most 20 characters long' })
  @Matches(/(?=.*[a-z])/, {
    message: 'Password must contain at least one lowercase letter',
  })
  @Matches(/(?=.*[A-Z])/, {
    message: 'Password must contain at least one uppercase letter',
  })
  @Matches(/(?=.*\d)/, {
    message: 'Password must contain at least one number',
  })
  @Matches(/(?=.*[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?])/, {
    message: 'Password must contain at least one special character',
  })
  password: string;

  @ApiProperty({
    example: 'Password123!',
    description: 'Confirm the new password',
  })
  @IsNotEmpty({ message: 'Please confirm your password' })
  @IsString()
  @Match('password', { message: 'Passwords do not match' })
  retryPassword: string;

  @ApiProperty({
    example: 'token-string',
    description: 'The reset token',
  })
  @IsNotEmpty({ message: 'token is not empty' })
  @IsString({ message: 'token must be a string' })
  token: string;
}

export class UpdateUserDto extends PartialType(CreateUserDto) {
  @ApiProperty({
    example: '123456',
    description: 'The PIN of the cashier',
    required: false,
  })
  @IsOptional()
  @IsString({ message: 'pin must be a string' })
  pin?: string;

  @ApiProperty({
    example: 'john_doe',
    description: 'The username of the user',
    required: false,
  })
  @IsOptional()
  @IsString({ message: 'username must be a string' })
  username?: string;
}
