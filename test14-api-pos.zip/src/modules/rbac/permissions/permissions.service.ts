import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { errorPermissionMessage } from 'src/libs/errors/error_permission';
import { successPermissionMessage } from 'src/libs/success/success_permission';
import { PermissionResponse } from 'src/types/response/permission.type';
import { Repository } from 'typeorm';
import { CreatePermissionDto } from './dto/create-permission.dto';
import { UpdatePermissionDto } from './dto/update-permission.dto';
import { Permission } from './entities/permission.entity';

@Injectable()
export class PermissionsService {
  constructor(
    @InjectRepository(Permission)
    private readonly permissionRepository: Repository<Permission>,
  ) {}
  // create permission
  async create(
    createPermissionDto: CreatePermissionDto,
  ): Promise<PermissionResponse> {
    // create permission
    const newPermission =
      this.permissionRepository.create(createPermissionDto);
    await this.permissionRepository.save(newPermission);
    return {
      message: successPermissionMessage.SUCCESS_PERMISSION_CREATED,
    };
  }

  // find all permissions
  async findAll(): Promise<PermissionResponse> {
    // find all permissions
    const permissions = await this.permissionRepository.find();
    if (permissions.length === 0) {
      throw new HttpException(
        {
          Error: {
            field: 'general',
            body: errorPermissionMessage.ERR_PERMISSION_LIST_FOUND_FAILED,
          },
        },
        HttpStatus.NOT_FOUND,
      );
    }
    return {
      message: successPermissionMessage.SUCCESS_PERMISSION_LIST_FOUND,
      datas: permissions.map((item) => ({
        id: item.id,
        module: item.module,
        action: item.action,
        description: item.description,
        createdAt: item.createdAt,
        updatedAt: item.updatedAt,
      })),
    };
  }

  // find one permissions
  async findOne(id: string): Promise<PermissionResponse> {
    // find one permission
    const permission = await this.permissionRepository.findOne({
      where: {
        id,
      },
    });
    if (!permission) {
      throw new HttpException(
        {
          Error: {
            field: 'general',
            body: errorPermissionMessage.ERR_PERMISSION_NOT_FOUND,
          },
        },
        HttpStatus.NOT_FOUND,
      );
    }
    return {
      message: successPermissionMessage.SUCCESS_PERMISSION_FOUND,
      data: {
        id: permission.id,
        module: permission.module,
        action: permission.action,
        description: permission.description,
        createdAt: permission.createdAt,
        updatedAt: permission.updatedAt,
      },
    };
  }

  // find permission by action
  async findByAction(action: string): Promise<PermissionResponse> {
    const permission = await this.permissionRepository.findOne({
      where: {
        action,
      },
    });
    if (!permission) {
      return {
        message: errorPermissionMessage.ERR_PERMISSION_NOT_FOUND,
        data: null,
      };
    }
    return {
      message: successPermissionMessage.SUCCESS_PERMISSION_FOUND,
      data: {
        id: permission.id,
        module: permission.module,
        action: permission.action,
        description: permission.description,
        createdAt: permission.createdAt,
        updatedAt: permission.updatedAt,
      },
    };
  }

  // Ensure permission exists, create if not
  async ensurePermission(
    module: string,
    action: string,
    description: string,
  ): Promise<void> {
    const existing = await this.findByAction(action);
    if (!existing.data) {
      await this.create({ module, action, description });
    }
  }

  // update permission
  async update(
    id: string,
    updatePermissionDto: UpdatePermissionDto,
  ): Promise<PermissionResponse> {
    // find one permission
    await this.findOne(id);
    // update permission
    await this.permissionRepository.update(id, updatePermissionDto);
    return {
      message: successPermissionMessage.SUCCESS_PERMISSION_UPDATED,
    };
  }

  // delete permission
  async remove(id: string): Promise<PermissionResponse> {
    // find one permission
    await this.findOne(id);
    // delete permission
    await this.permissionRepository.delete(id);
    return {
      message: successPermissionMessage.SUCCESS_PERMISSION_DELETED,
    };
  }
}
