import { forwardRef, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CloudinaryModule } from 'src/common/cloudinary/cloudinary.module';
import { UserLogsModule } from '../user_logs/user_logs.module';
import { CategoriesModule } from './categories/categories.module';
import { ProductVariant } from './entities/product-variant.entity';
import { Product } from './entities/product.entity';
import { ProductVariantsModule } from './product-variants/product-variants.module';
import { ProductsController } from './products.controller';
import { ProductsService } from './products.service';

@Module({
  controllers: [ProductsController],
  providers: [ProductsService],
  imports: [
    TypeOrmModule.forFeature([Product, ProductVariant]),
    CategoriesModule,
    forwardRef(() => ProductVariantsModule),
    CloudinaryModule,
    UserLogsModule,
  ],
  exports: [ProductsService],
})
export class ProductsModule {}
