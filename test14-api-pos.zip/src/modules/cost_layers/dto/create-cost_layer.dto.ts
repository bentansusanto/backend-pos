export class CreateCostLayerDto {}
