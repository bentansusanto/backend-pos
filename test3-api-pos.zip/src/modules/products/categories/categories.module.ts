import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Category } from '../entities/category.entities';
import { CategoriesController } from './categories.controller';
import { CategoriesService } from './categories.service';
import { PermissionsModule } from '../../rbac/permissions/permissions.module';

@Module({
  controllers: [CategoriesController],
  providers: [CategoriesService],
  imports: [TypeOrmModule.forFeature([Category]), PermissionsModule],
  exports: [CategoriesService],
})
export class CategoriesModule {}
