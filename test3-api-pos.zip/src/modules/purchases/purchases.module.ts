import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PurchaseItems } from './entities/purchase-items.entity';
import { Purchase } from './entities/purchase.entity';
import { PurchasesController } from './purchases.controller';
import { PurchasesService } from './purchases.service';
import { PermissionsModule } from '../rbac/permissions/permissions.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([Purchase, PurchaseItems]),
    PermissionsModule,
  ],
  controllers: [PurchasesController],
  providers: [PurchasesService],
  exports: [PurchasesService],
})
export class PurchasesModule {}
