export class CreatePurchaseReceivingDto {}
