export class CreatePurchaseDto {}
