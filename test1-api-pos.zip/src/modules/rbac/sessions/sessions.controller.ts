import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
} from '@nestjs/common';
import { SessionsService } from './sessions.service';
import { CreateSessionDto } from './dto/create-session.dto';
import { UpdateSessionDto } from './dto/update-session.dto';

@Controller('sessions')
export class SessionsController {
  constructor(private readonly sessionsService: SessionsService) {}

  @Post()
  create() {
    return;
  }

  @Get()
  findAll() {
    return;
  }

  @Get(':id')
  findOne() {
    return;
  }

  @Patch(':id')
  update() {
    return;
  }

  @Delete(':id')
  remove() {
    return;
  }
}
