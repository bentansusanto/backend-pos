import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  Post,
  Put,
  Query,
  UseGuards,
} from '@nestjs/common';
import { CurrentUser } from 'src/common/decorator/current-user.decorator';
import { JwtAuthGuard } from 'src/common/guards/jwt-auth.guard';
import { User } from 'src/modules/rbac/users/entities/user.entity';
import { WebResponse } from 'src/types/response/index.type';
import { CreateProductVariantDto } from '../dto/create-product-variant.dto';
import { ProductVariantsService } from './product-variants.service';

@UseGuards(JwtAuthGuard)
@Controller('variants')
export class ProductVariantsController {
  constructor(
    private readonly productVariantsService: ProductVariantsService,
  ) {}

  @Post()
  @HttpCode(HttpStatus.CREATED)
  async create(
    @Body() createProductVariantDto: CreateProductVariantDto,
    @CurrentUser() currentUser: User,
  ): Promise<WebResponse> {
    const result = await this.productVariantsService.create(
      createProductVariantDto,
      currentUser?.id,
    );
    return {
      message: result.message,
      data: result.data,
    };
  }

  @Put(':id')
  async update(
    @Param('id') id: string,
    @Body() updateProductVariantDto: CreateProductVariantDto,
    @CurrentUser() currentUser: User,
  ): Promise<WebResponse> {
    const result = await this.productVariantsService.update(
      id,
      updateProductVariantDto,
      currentUser?.id,
    );
    return {
      message: result.message,
      data: result.data,
    };
  }

  @Delete(':id')
  async delete(
    @Param('id') id: string,
    @CurrentUser() currentUser: User,
  ): Promise<WebResponse> {
    const result = await this.productVariantsService.delete(
      id,
      currentUser?.id,
    );
    return {
      message: result.message,
    };
  }

  @Get(':id')
  async findOne(@Param('id') id: string): Promise<WebResponse> {
    const result = await this.productVariantsService.findOne(id);
    return {
      message: result.message,
      data: result.data,
    };
  }

  @Get()
  async findAll(
    @Query('branch_id') queryBranchId?: string,
  ): Promise<WebResponse> {
    // Only filter by branch if explicitly requested via query param.
    // This ensures /variants without ?branch_id returns ALL variants
    // (needed for Purchase Orders where stock may be 0).
    const result = await this.productVariantsService.findAll(queryBranchId);
    return {
      message: result.message,
      data: result.datas,
    };
  }
}
